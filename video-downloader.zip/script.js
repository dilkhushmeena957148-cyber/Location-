class VideoDownloader {
  constructor() {
    this.videoUrl = document.getElementById('videoUrl');
    this.downloadBtn = document.getElementById('downloadBtn');
    this.loading = document.getElementById('loading');
    this.results = document.getElementById('results');
    
    this.downloadBtn.addEventListener('click', () => this.analyzeVideo());
    this.videoUrl.addEventListener('keypress', (e) => {
      if (e.key === 'Enter') this.analyzeVideo();
    });
  }
  
  async analyzeVideo() {
    const url = this.videoUrl.value.trim();
    if (!url) {
      this.showError('Please enter a video URL');
      return;
    }
    
    this.loading.classList.remove('hidden');
    this.results.classList.add('hidden');
    this.downloadBtn.disabled = true;
    this.downloadBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Analyzing...';
    
    try {
      const videoInfo = await this.extractVideoInfo(url);
      this.displayResults(videoInfo);
    } catch (error) {
      console.error('Error:', error);
      this.showError('Unable to process this video. Please check the URL and try again.');
    } finally {
      this.loading.classList.add('hidden');
      this.downloadBtn.disabled = false;
      this.downloadBtn.innerHTML = '<i class="fas fa-search"></i><span>Analyze</span>';
    }
  }
  
  async extractVideoInfo(url) {
    // YouTube video ID extraction
    const videoIdMatch = url.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/)([^&\n?#]+)/);
    if (videoIdMatch) {
      return await this.getYouTubeInfo(videoIdMatch[1]);
    }
    
    // For demo purposes, return mock data for other platforms
    return this.getMockVideoInfo(url);
  }
  
  async getYouTubeInfo(videoId) {
    // Using public YouTube Data API v3 (requires API key for production)
    // For demo, using mock data with realistic structure
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve({
          title: "Sample Video Title - High Quality Demo",
          thumbnail: `https://img.youtube.com/vi/${videoId}/maxresdefault.jpg`,
          author: "Demo Channel",
          duration: "4:23",
          formats: [
            { quality: '1080p', format: 'MP4', size: '45 MB', url: `https://example.com/download/1080p/${videoId}` },
            { quality: '720p', format: 'MP4', size: '32 MB', url: `https://example.com/download/720p/${videoId}` },
            { quality: '480p', format: 'MP4', size: '22 MB', url: `https://example.com/download/480p/${videoId}` },
            { quality: 'Audio', format: 'MP3', size: '5 MB', url: `https://example.com/download/audio/${videoId}` }
          ]
        });
      }, 2000);
    });
  }
  
  getMockVideoInfo(url) {
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve({
          title: "Video from " + new URL(url).hostname,
          thumbnail: 'https://via.placeholder.com/400x225/667eea/ffffff?text=Video+Preview',
          author: "Original Uploader",
          duration: "3:45",
          formats: [
            { quality: 'HD', format: 'MP4', size: '28 MB', url: '#' },
            { quality: 'SD', format: 'MP4', size: '15 MB', url: '#' },
            { quality: 'Audio', format: 'MP3', size: '4 MB', url: '#' }
          ]
        });
      }, 1500);
    });
  }
  
  displayResults(videoInfo) {
    const resultsHtml = `
            <div class="video-info">
                ${videoInfo.thumbnail ? `<img src="${videoInfo.thumbnail}" alt="Thumbnail" class="video-thumbnail" onerror="this.src='https://via.placeholder.com/400x225/ddd/999?text=No+Preview'">` : ''}
                <div class="video-title">${videoInfo.title}</div>
                <div class="video-duration"><i class="fas fa-clock"></i> ${videoInfo.duration}</div>
                <div class="video-author"><i class="fas fa-user"></i> ${videoInfo.author}</div>
            </div>
            <div class="download-options">
                ${videoInfo.formats.map(format => `
                    <button class="download-btn" onclick="window.open('${format.url}', '_blank')">
                        <span>Download ${format.quality} ${format.format}</span>
                        <span class="quality-badge">${format.quality}</span>
                    </button>
                `).join('')}
            </div>
        `;
    
    this.results.innerHTML = resultsHtml;
    this.results.classList.remove('hidden');
    this.results.scrollIntoView({ behavior: 'smooth' });
  }
  
  showError(message) {
    this.results.innerHTML = `<div class="error"><i class="fas fa-exclamation-triangle"></i> ${message}</div>`;
    this.results.classList.remove('hidden');
  }
}

// Initialize when page loads
document.addEventListener('DOMContentLoaded', () => {
  new VideoDownloader();
});